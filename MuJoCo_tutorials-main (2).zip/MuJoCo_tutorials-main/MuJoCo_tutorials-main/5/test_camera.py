import os
import mujoco
import mujoco.viewer
import cv2
import numpy as np

duong_dan_xml = r"c:\Users\Admin\Downloads\MuJoCo_tutorials-main\MuJoCo_tutorials-main\5\main.xml"

os.chdir(os.path.dirname(duong_dan_xml))

model = mujoco.MjModel.from_xml_path("main.xml")
data = mujoco.MjData(model)

renderer = mujoco.Renderer(model, height=480, width=640)

with mujoco.viewer.launch_passive(model, data) as viewer:
    while viewer.is_running():
        mujoco.mj_step(model, data)
        viewer.sync()

        renderer.update_scene(data, camera="gripper_cam")
        img_rgb = renderer.render()
        img_bgr = cv2.cvtColor(img_rgb, cv2.COLOR_RGB2BGR)

        cv2.imshow("Gripper Camera View", img_bgr)
        
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

cv2.destroyAllWindows()