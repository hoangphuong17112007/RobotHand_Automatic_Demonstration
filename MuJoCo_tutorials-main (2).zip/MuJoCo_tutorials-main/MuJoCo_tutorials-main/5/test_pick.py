import os
import mujoco
import mujoco.viewer
import cv2
import numpy as np

# Đường dẫn đến file main.xml của bạn
xml_path = r"c:\Users\Admin\Downloads\MuJoCo_tutorials-main\MuJoCo_tutorials-main\5\main.xml"
os.path.dirname(xml_path)
os.chdir(os.path.dirname(xml_path))

model = mujoco.MjModel.from_xml_path("main.xml")
data = mujoco.MjData(model)

renderer = mujoco.Renderer(model, height=480, width=640)

with mujoco.viewer.launch_passive(model, data) as viewer:
    step_count = 0
    
    while viewer.is_running():
        step_count += 1
        
        # KỊCH BẢN ĐIỀU KHIỂN ROBOT GẮP THEO SỐ BƯỚC (STEP)
        if step_count < 400:
            # Giai đoạn 1: Mở kẹp và vươn tay tới vùng chứa linh kiện
            data.ctrl[0] = 0.0   # hip_ctrl
            data.ctrl[1] = -0.9  # hindarm_ctrl
            data.ctrl[2] = 1.0   # forearm_ctrl
            data.ctrl[3] = 0.0   # wrist_ctrl
            data.ctrl[4] = 0.0   # hand_ctrl (Mở kẹp rộng)
            
        elif 400 <= step_count < 800:
            # Giai đoạn 2: Hạ thấp đầu kẹp sát xuống vị trí linh kiện
            data.ctrl[1] = -0.7
            data.ctrl[2] = 0.8
            
        elif 800 <= step_count < 1200:
            # Giai đoạn 3: Đóng kẹp lại để kẹp chặt linh kiện
            data.ctrl[4] = 1.2   # hand_ctrl (Đóng kẹp)
            
        elif 1200 <= step_count < 1600:
            # Giai đoạn 4: Nhấc vật lên cao
            data.ctrl[1] = -1.1
            data.ctrl[2] = 1.2
        else:
            # Giữ nguyên trạng thái sau khi nhấc
            pass

        # Thực hiện bước mô phỏng vật lý
        mujoco.mj_step(model, data)
        viewer.sync()

        # Đọc dữ liệu từ cảm biến xúc giác gắn trên kẹp
        try:
            touch_force = data.sensor("gripper_touch_sensor").data[0]
            if touch_force > 0.005:
                print(f"[Cảm biến xúc giác] Đã chạm linh kiện! Lực ép: {touch_force:.4f} N")
        except Exception:
            pass

        # Cập nhật khung hình camera từ góc nhìn bàn kẹp
        renderer.update_scene(data, camera="gripper_cam")
        img_rgb = renderer.render()
        img_bgr = cv2.cvtColor(img_rgb, cv2.COLOR_RGB2BGR)

        cv2.imshow("Gripper Camera View", img_bgr)
        
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

cv2.destroyAllWindows()